<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
	header('Location: https://ifwi4.c1.biz/login/');
	exit;
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Scripts Page</title>
		<link href="style.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer">
	</head>
	<body class="loggedin">
		<nav class="navtop">
			<div>
				<h1>The IM Group</h1>
                <a href="home.php"><i class="fas fa-home"></i>Home</a>
				<a href="profile.php"><i class="fas fa-user-circle"></i>Profile</a>
				<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
			</div>
		</nav>
		<div class="content">
			<h2>Scripts Page</h2>
			<div>
				<p>Useful scripts below:</p>
				<table>
					<tr>
						<td>Open a page about:blank cloaked.</td>
						<td>
                            <input id="blank" placeholder="Enter URL here" style="width:200px"></input>
                            <button onclick="blank();">Cloak</button>
                        </td>
					</tr>
					<tr>
						<td>Cloak this page.</td>
                        <td><input id="cloaktitle" placeholder="Page Title"><input id="cloakimg" placeholder="Enter Favicon URL (NO HTTPS)"><button onclick="cloak();">Cloak Page</button></td>
					</tr>
					<tr>
						<td>All Tickets Created:</td>
						<td><?=$tickets?></td>
					</tr>
				</table>
                <p><b>Useful Links:</b></p>
                <table>
                    <tr>
                        <td><a href="https://ifwi4.c1.biz/ifwi/ifwi-1/">Use IFWI-1 on your computer.</a></td>
                    </tr>
                    <tr>
                        <td><a href="https://talkai.info/chat">Use ChatGPT online, no account, unblocked.</a></td>
                    </tr>
                    <tr>
                        <td><a href="https://eaglercraft.ru/">Play Minecraft Copy.</a></td>
                    </tr>
                </table>
			</div>
		</div>
	</body>
</html>
<script>   
function cloak() {
        document.title = document.getElementById("cloaktitle").value;
		var link = document.querySelector("link[rel~='icon']");
		if (!link) {
    			link = document.createElement('link');
    			link.rel = 'icon';
    			document.getElementsByTagName('head')[0].appendChild(link);
		}
		let domain = document.getElementById("cloakimg").value;
		link.href = "https://www.google.com/s2/favicons?domain=" + domain + "&sz=16";

}
function blank() {
	var url = document.getElementById("blank").value;
	var urlObj = new window.URL(window.location.href);
	win = window.open();
	win.document.body.style.margin = "0";
	win.document.body.style.height = "100vh";
	var iframe = win.document.createElement("iframe");
	iframe.style.border = "none";
	iframe.style.width = "100%";
	iframe.style.height = "100%";
	iframe.style.margin = "0";
	iframe.referrerpolicy = "no-referrer";
	iframe.allow = "fullscreen";
	iframe.src = url.toString();
	win.document.body.appendChild(iframe);
}
  </script>