<!DOCTYPE html>
<link rel="stylesheet" href="style.css">
<div class="topnav" id="navbar">
  <a id="general" href="/">General Chat</a>
  <a id="settings" href="/navbar.php?settings">Settings</a>
  <a id="contact" href="/navbar.php?contact">Contact Admin</a>
  <a id="logout" href="/navbar.php?logout">Log Out</a>
<br></br>
</div>
<div id="settings" style="display:none;">
<input id="reloadTime" placeholder="Enter Message Reload Time"></input> Reload: <p id="reload1">5000</p> ms
<button onclick="changeReload();">Save</button>
<br></br>If you want to change the reload time, enter the time in milliseconds. If you want no reload time, put "NO".
  <script>
function changeReload() {i
  var reloadTime = document.getElementById("reloadTime").value;
    if (reloadTime == "NO") {
      reloadTime = 999999389896802573486730456456;
      localStorage.setItem("reload", reloadTime);
      reloadTime = document.getElementById("reloadTime").value = "";
      document.getElementById("reload1").innerHTML = "Reload time changed to NO";
    } else {
      localStorage.setItem("reload", reloadTime);
      reloadTime = document.getElementById("reloadTime").value = "";
      document.getElementById("reload1").innerHTML = reloadTime;
    }
}
  </script>
</div>

<div id="contact" style="display:none;">
  <form method="post">
  <textarea id="contact" name="contact" rows="5" cols="50">Send ifwi4 [ADMIN] any message, suggestion, bug report, or complaint you want here.</textarea><button name="contact">Send contact message</button>
</form>
<?php
if(array_key_exists("contact", $_POST)) { 
  contact();
} 
function contact() {
  $contact = $_POST["contact"];
  date_default_timezone_set('America/Los_Angeles');
  $date = date('m:d:Y');
  $time = date("H:i:s");
  $report = $contact . " | Timestamp: " . $date  . " ". $time;
  $filename = 'contact.txt';
  $file = fopen($filename, 'a');
  $report = "\n" . $report;
  fwrite($file, $report);
  fclose($file);
  echo "Contact message sent!";
}
?>
</form>
</div>
<script>
  if (location.href == "https://ifwi4.c1.biz/PHPmail/navbar.php?logout") {
    document.getElementById("navbar").style.display = "none";
    localStorage.clear();
    document.write('<br></br>Sucessfully logged out!<br></br><a href="https://email.aengine.repl.co">Click here to go back to the home page.</a>');
  }
  if (location.href == "https://email.aengine.repl.co/navbar.php?settings") {
    document.getElementById("settings").style.display = "block";
  }
  if (location.href == "https://email.aengine.repl.co/navbar.php?contact") {
    document.getElementById("navbar").style.display = "block";
  }
</script>