<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
	header('Location: https://ifwi4.c1.biz/login/');
	exit;
}
?>
<!DOCTYPE html>
<html>
  <link rel="stylesheet" href="style.css">
<head>
  <div class="topnav">
    <a href="https://ifwi4.c1.biz/ifwi/PHPmail">General Chat</a>
    <a class="active" href="https://ifwi4.c1.biz/ifwi/PHPmail/technology.php">Tech Chat</a>
    <a href="https://ifwi4.c1.biz/ifwi/PHPmail/homework.php">Homework Chat</a>
    <a href="https://ifwi4.c1.biz/ifwi/home.php">IM Group Home</a>
    <a href="https://ifwi4.c1.biz/ifwi/logout.php">Log Out</a>
  </div>
  <title>IM Group Email</title>
  <h1 style="color:green;"> 
    <center>
    Welcome to the IM Group Email!
    </center>
  </h1> 
<script> 
function reload() {
const iframe = document.getElementById("chat");
iframe.src = "https://ifwi4.c1.biz/ifwi/PHPmail/displayers/technology.php/;
}
setInterval(reload, 5000);
function italic() {
      document.getElementById("message").value = document.getElementById("message").value + " *`Text`*";
}
function bold() { 
      document.getElementById("message").value = document.getElementById("message").value + " **`Text`**";
}
function underline() {
      document.getElementById("message").value = document.getElementById("message").value + " ***`Text`***"; 
}
</script>
</head>
<iframe id="chat" src="displayers/technology.php" height="400px" width="99%" style="border:3px solid black;"></iframe>

<form id="sendmessage" method="post"> 
<input autocomplete='off' spellcheck='false' autocorrect='off' id='message' name="message" placeholder='Press "Enter" to send a message!' style='width:1000px;height:50px;left:0px' maxlength="100"></input>

<button name="send" id="send" style="width:150px;height:50px;left:0px">Send your message!</button>
</form>
<button onclick="italic();"><i>Italic</i> Text</button>
<button onclick="bold();"><b>Bold</b> Text</button>
<button onclick="underline();"><u>Underline</u> Text</button>
<br></br>This chat is still in development. However, this is the stable website, so expect a bit less lag. However, if you want to go to the old website, go to email.ifwi.repl.co

<?php 
if(array_key_exists("send", $_POST)) { 
  send();
} 
function send() {
  $username = $_SESSION['name'];
  $message = $_POST["message"];
  $message = str_replace("***`", "<u>", $message);
  $message = str_replace("`***", "</u>", $message);
  $message = str_replace("**`", "<b>", $message);
  $message = str_replace("`**", "</b>", $message);
  $message = str_replace("*`", "<i>", $message);
  $message = str_replace("`*", "</i>", $message);
        
function filterProfanity($message) {
  $profanityWords = array("fuck", "fu ck", "fuc k", "shit", "nigger", "nigga", "nigg", "nig ger", "nigg er", "bitch"); 

  foreach ($profanityWords as $word) {
    str_replace(" ", "", $word);
    $replacement = str_repeat('*', strlen($word));
    $message = str_ireplace($word, $replacement, $message);
  }

  return $message;
}

$message = filterProfanity($message);
         
  $file = "displayers/logs/technology.txt";
  $current = file_get_contents($file);
  file_put_contents($file, "<b>" . $username . "</b> said: " . $message . $current);
  $content = file_get_contents($file);
  $lines = explode("\n", $content);
  array_unshift($lines, '');
  $newContent = implode("\n", $lines);
  file_put_contents($file, $newContent);
  $file = fopen("displayers/logs/technology.txt", "r+");
  $contents = fread($file, filesize("displayers/logs/technology.txt"));
  rewind($file);
  fwrite($file, "\n-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
  fwrite($file, $contents);
  fclose($file);
}
?>
</html>











<!-- Made by ifwi4 -->