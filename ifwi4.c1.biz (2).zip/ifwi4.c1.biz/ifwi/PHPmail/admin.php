<?php
session_start();
if ($_SESSION["name"] !== "ifwi4") {
        header("Location: https://ifwi4.c1.biz/ifwi/PHPmail/");
        exit;
}
?>
<!DOCTYPE html>
<html>
<body>
<title>Admin Panel</title>
<h2>Admin Panel</h2>
  <iframe id="displayer" src="displayers/general.php" height="50%" width="99%" style="border:3px solid black;"></iframe>
  <label for="chat">Choose a chat</label>
  <select id="chat" name="chat">
            <option id="general" value="general.php">General Chat</option>
            <option id="technology" value="technology.php">Tech chat</option>
            <option id="homework" value="homework.php">Homework Chat</option>
  </select>
  <button onclick="setChat();">Go</button>
<script>
        function setChat() {
            var chat = document.getElementById("chat").value;
            localStorage.setItem("chat", chat);                                
            updateChat();
        }
        function updateChat() {
            var chat = localStorage.getItem("chat") || "general.php";
            if (chat == "general.php") {
                    document.getElementById("general").selected = "selected";
            } else if (chat == "technology.php") {
                    document.getElementById("technology").selected = "selected";
            } else if (chat == "homework.php") {
                    document.getElementById("homework").selected = "selected";
            }
            document.getElementById("logs").value = chat;
            document.getElementById("displayer").src = "https://ifwi4.c1.biz/ifwi/PHPmail/displayers/" + chat;
        }
        updateChat();
</script>
<form method="post">
<input name="name" value="ifwi4 [ADMIN]"></input>
<input name="logs" id="logs" value="general.txt"></input>
<input autocomplete='off' spellcheck='false' autocorrect='off' id='message' name="message" placeholder='Press "Enter" to send a message!' style='width:750px;height:50px;left:0px'></input>

<button name="send" id="send" onclick="updateChat();" style="width:150px;height:50px;left:0px">Send your message!</button>
</form>
<script>function reload() { const iframe = document.getElementById('displayer'); iframe.src = iframe.src; } setInterval(reload, 5000) </script>
  
<form method="post">
        <button name="clearchat">Clear Chat</button>
</form>
<form method="post">
        <input name="addmessage" placeholder="Enter message here!"></input>
        <button name="addmessageb">Manually add message</button>
</form>
<form>
        <button name="logout">Log out everyone permanently. Reversable by clearing chat</button>
</form>
<form>
<button name="banuser">Ban user</button>
<input name="banuserinput" placeholder="Enter username to ban here!"></input>
</form>
  
<?php
function divider() {
        $file = str_replace(".php", ".txt", "displayers/logs/" . $_POST["logs"]);
        $current = file_get_contents($file);
        file_put_contents($file, "\n-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n" . $current);
}
if(array_key_exists("clearchat", $_POST)) { 
        clearchat();
} 
function clearchat() {
        $file = str_replace(".php", ".txt", "displayers/logs/" . $_POST["logs"]);
        file_put_contents($file, "<b>Chat cleared by Admin!</b>");
        divider();
        echo "Chat sucessfully cleared!";
}
if(array_key_exists("addmessageb", $_POST)) { 
        addmessage();
} 
function addmessage() {
        $manualmessage = $_POST["addmessage"];
        $file = $_POST["logs"];
        $current = file_get_contents($file);
        file_put_contents($file, $manualmessage . $current);
        echo $manualmessage . " was sucessfully added!";
}
if(array_key_exists("banuser", $_POST)) { 
        banuser();
} 
function banuser() {
        $ban = $_POST["banuserinput"];
        $file = $_POST["logs"];
        $current = file_get_contents($file);
        file_put_contents($file, "<script>var name = localStorage.getItem('rName', username); if (name =='".$ban . "') {alert('You have been banned. If you believe this was a mistake, contact the admin. '); location.href=location.href;localStorage.clear();}</script><b>Banned user " . $ban . ".</b>". $current);
        echo $ban . " was sucessfully banned!";
}
function admin($command, $type, $sender = "ifwi4 [ADMIN]") {
        if ($type == "ping") {
                $target = strstr($command, " return", true);
                $target = str_replace("/ping ", "", $target);
                if (strpos($command, "return status")) { 
                        
                }  elseif (strpos($command, "return load_time")) {
                        $message = $sender . " used /ping. Ping sent at displayers/logs/" . $target . ", ping recieved at <script>var start = new Date(); window.onload = function() { var done = new Date(); var loadTime = done - start; } document.write(loadTime);</script>ms load time.";
                        botsend($message, $target);
                } else {
                        $message = "Incorrect format using /ping! Format: /ping <target> return <command>";
                        botsend($message);
                }
        } elseif ($type = "purge") {
                $target = strstr($command, " <word=", true);
                $target = str_replace("/purge ", "", $target);
                $word = strstr($command, ">", true);
                $word = str_replace("/purge " . $target . " <word=", "", $word);
                $file = "displayers/logs/" . $target;
                $contents = file_get_contents($file);
                $contents = str_replace($word, "", $contents);
                file_put_contents($file, $contents);
                $message = $sender . " got rid of all words " . $word . " in " . $file;
                botsend($message, $file);
        }
}
function botsend($message, $target = "general.txt") {
        $current = file_get_contents($target);
        file_put_contents($target, "<b>Debug [BOT]</b> said: " . $message . $current);
        $current = file_get_contents($target);
        file_put_contents($target, "\n-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n" . $current);
}
if(array_key_exists("send", $_POST)) { 
        send();
} 
function send() {
        $message = $_POST["message"];
        $name = $_POST["name"];
        $file = str_replace(".php", ".txt", "displayers/logs/" . $_POST["logs"]);
        if (strpos($message, "/ping") !== false) {
                admin($message, "ping");
        } elseif (strpos($message, "/purge") !== false) {
                admin($message, "purge");
        } else {
                $current = file_get_contents($file);
                file_put_contents($file, "<b>" . $name . "</b> said: " . $message . $current);
                divider();
        }
}
if(array_key_exists("logout", $_POST)) { 
        logout();
} 
function logout() {
  $file = $_POST["file"];
  file_put_contents($file, "<?php session_start();session_destroy(); ?>
?><b>ifwi4 [ADMIN]</b> shut down chat undefinetly.");
  echo "Sucessfully shut down chat.";
}

?>
</body>
</html>
<!-- Made by ifwi4 -->