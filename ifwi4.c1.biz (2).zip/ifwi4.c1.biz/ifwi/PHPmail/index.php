<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
	header('Location: https://ifwi4.c1.biz/login');
	exit;
}
$DATABASE_HOST = 'fdb1027.biz.nf';
$DATABASE_USER = '4306902_ifwi';
$DATABASE_PASS = 'Sissyiscute1';
$DATABASE_NAME = '4306902_ifwi';
$con = mysqli_connect($DATABASE_HOST, $DATABASE_USER, $DATABASE_PASS, $DATABASE_NAME);
if (mysqli_connect_errno()) {
	exit('Failed to connect to MySQL: ' . mysqli_connect_error());
}
$stmt = $con->prepare('SELECT ranks FROM accounts WHERE id = ?');
// In this case we can use the account ID to get the account info.
$stmt->bind_param('i', $_SESSION["id"]);
$stmt->execute();
$stmt->bind_result($_SESSION["ranks"]);
$stmt->fetch();
$stmt->close();
?>
<!DOCTYPE html>
<html>
  <link rel="stylesheet" href="style.css">
  <script src="script.js"></script>
<head>
  <div class="topnav">
    <a class="active" href="https://ifwi4.c1.biz/PHPmail">General Chat</a>
    <a href="https://ifwi4.c1.biz/ifwi/PHPmail/technology.php">Tech Chat</a>
    <a href="https://ifwi4.c1.biz/ifwi/PHPmail/homework.php">Homework Chat</a>
    <a href="https://ifwi4.c1.biz/ifwi/home.php">IM Group Home</a>
    <a href="https://ifwi4.c1.biz/ifwi/logout.php">Log Out</a>
  </div>
  <title>IM Group Email</title>
  <h1 style="color:green;"> 
    <center>
    Welcome to the IM Group Email!
    </center>
  </h1> 
<script>
var reloadTime = localStorage.getItem("reloadTime") || 5000;
function setReload() {
        var reloadTime = document.getElementById("reloadInput").value * 1000;
        localStorage.setItem("reloadTime", reloadTime);
        document.getElementById("reloadTime").innerHTML = "Chat reloads every " + reloadTime/1000 + " seconds.";
}
function reload() {
        const iframe = document.getElementById('general');
        iframe.src = iframe.src;
}
setInterval(reload, reloadTime);
function italic() {
      document.getElementById("message").value = document.getElementById("message").value + " *`Text`*";
}
function bold() { 
      document.getElementById("message").value = document.getElementById("message").value + " **`Text`**";
}
function underline() {
      document.getElementById("message").value = document.getElementById("message").value + " ***`Text`***"; 
}
</script>
</head>
<iframe id="general" src="displayers/general.php" height="400px" width="99%" style="border:3px solid black;"></iframe>

<form id="sendmessage" method="post"> 
<input autocomplete='off' spellcheck='false' autocorrect='off' id='message' name="message" placeholder='Press "Enter" to send a message!' required style='width:1000px;height:50px;left:0px' maxlength="100"></input>

<button name="send" id="send" style="width:150px;height:50px;left:0px">Send your message!</button>
</form>
<button onclick="italic();"><i>Italic</i> Text</button>
<button onclick="bold();"><b>Bold</b> Text</button>
<button onclick="underline();"><u>Underline</u> Text</button>
<input id="reloadInput" placeholder="Enter the amount of time in seconds you want the chat to reload in seconds!" style="width:400px"></input>
<button onclick="setReload();">Set reload time</button>
<p id="reloadTime">Reloads once every 5 seconds.</p>
<br></br>This chat is still in development. However, this is the stable website, so expect a bit less lag. 

<?php 
if(array_key_exists("send", $_POST)) { 
        send();
} 
function send() {
  $username = $_SESSION['name'];
  
  if ($username == "ifwi4") {
          $username = $username . " <button onclick='openPopup();'>Profile</button><div id='popup' class='popup'><div class='popup-content'>" . $_SESSION["ranks"] . "<span onclick='closePopup()' class='close'>&times;</span></div></div>";
          //$username = $username . " <span style='color:red;'>[ADMIN] <span style='color:purple;'>[DEV]</span> <span style='color:green;'>[OG]</span>";
  } elseif ($username == "stalin") {
          $username = $username . " <span style='color:red;'>[STA</span><span style='color:yellow;'>LIN]</span> <span style='color:green;'>[OG]</span>";
  } elseif ($username == "anon1") {
          $username = $username . " <span style='color:green;'>[OG]</span>";
  } elseif ($username == "redfish") {
          $username = $username . " <span style='color:green;'>[OG]</span>";
  } elseif ($username == "susgamer") {
          $username = $username . " <span style='color:green;'>[OG]</span>";
  } elseif ($username == "iexist") {
          $username = $username . "";
  } 
  
  $message = $_POST["message"];
  $message = str_replace("***`", "<u>", $message);
  $message = str_replace("`***", "</u>", $message);
  $message = str_replace("**`", "<b>", $message);
  $message = str_replace("`**", "</b>", $message);
  $message = str_replace("*`", "<i>", $message);
  $message = str_replace("`*", "</i>", $message);
        
function filterProfanity($message) {
  $profanityWords = array('fuck', 'shit', 'nigger', 'nigga', 'nigg', 'bitch');

  foreach ($profanityWords as $word) {
    $replacement = str_repeat('*', strlen($word));
    $message = str_ireplace($word, $replacement, $message);
  }

  return $message;
}

$message = filterProfanity($message);
         
  $file = "displayers/logs/general.txt";
  $current = file_get_contents($file);
  file_put_contents($file, "<b>" . $username . "</b> said: " . $message . $current);
  $content = file_get_contents($file);
  $lines = explode("\n", $content);
  array_unshift($lines, '');
  $newContent = implode("\n", $lines);
  file_put_contents($file, $newContent);
  $file = fopen("displayers/logs/general.txt", "r+");
  $contents = fread($file, filesize("displayers/logs/general.txt"));
  rewind($file);
  fwrite($file, "\n-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
  fwrite($file, $contents);
  fclose($file);
}
?>
</html>











<!-- Made by ifwi4 -->