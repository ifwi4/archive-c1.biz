<?php
session_start();
if (!isset($_SESSION["loggedin"])) {
        header("Location: https://ifwi4.c1.biz/login/");
        exit;
}
?>
<?php echo nl2br(file_get_contents("logs/technology.txt")); ?>