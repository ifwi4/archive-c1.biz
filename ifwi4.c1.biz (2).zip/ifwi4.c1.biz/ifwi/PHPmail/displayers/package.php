<style>
.popup {
  display: none; 
  position: fixed;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  background-color: rgba(0, 0, 0, 0.5); 
  z-index: 999; 
}

.popup-content {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background-color: white;
  padding: 20px;
  border-radius: 5px;
}

.close {
  position: absolute;
  top: 10px;
  right: 20px;
  font-size: 22px;
  font-weight: bold;
  cursor: pointer;
}
</style>
<script>
function openPopup() {
		document.getElementById("popup").style.display = "block";
}

function closePopup() {
		document.getElementById("popup").style.display = "none";
}
</script>