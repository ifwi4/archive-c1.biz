<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
	header('Location: https://ifwi4.c1.biz/login/');
	exit;
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Ticket</title>
		<link href="https://ifwi4.c1.biz/ifwi/style.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer">
	</head>
	<body class="loggedin">
		<nav class="navtop">
			<div>
				<h1>Ticket Support</h1>
                <a href="https://ifwi4.c1.biz/ifwi/home.php/"><i class="fas fa-home"></i>Home</a>
				<a href="https://ifwi4.c1.biz/ifwi/profile.php/"><i class="fas fa-user-circle"></i>Profile</a>
				<a href="https://ifwi4.c1.biz/ifwi/logout.php/"><i class="fas fa-sign-out-alt"></i>Logout</a>
			</div>
		</nav>
		<div class="content">
			<h2>Ticket Number example-ticket [OPEN]/[CLOSED]</h2>
			<div>
               	<p>A ticket with [OPEN] means the admin has not gotten to it yet. A ticket with [CLOSED] has been resloved.
                <br>You can view a ticket by going to ifwi4.c1.biz/ifwi/ticket/TICKET_NUMBER.php</br>
                Nobody can view your tickets except for the admin and you.</p>
                <p>After you <a href="https://ifwi4.c1.biz/ifwi/ticket/ticket.php">make a ticket</a>, you will be given a ticket number.
				<p>Your ticket details are below:</p>
				<table>
					<tr>
						<td>Username:</td>
						<td>Your name here.</td>
					</tr>
					<tr>
						<td>Question/Feeback:</td>
                            <td>All text that you entered into a ticket form named "Question/Feedback" will be here. Rules: No spamming, no making unnesscary tickets, no being Ben.</td>
					</tr>
					<tr>
						<td>Admin Response</td>
						<td>There might not be a response here depending on if the admin has looked at it yet.</td>
					</tr>
				</table>
			</div>
		</div>
	</body>
</html>














<!-- Made by ifwi4 -->