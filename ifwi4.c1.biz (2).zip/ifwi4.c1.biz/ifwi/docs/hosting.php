<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
	header('Location: https://ifwi4.c1.biz/login/');
	exit;
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Hosting Manual</title>
		<link href="https://ifwi4.c1.biz/ifwi/style.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer">
	</head>
	<body class="loggedin">
		<nav class="navtop">
			<div>
				<h1>The IM Group</h1>
                <a href="https://ifwi4.c1.biz/ifwi/home.php"><i class="fas fa-home"></i>Home</a>
				<a href="https://ifwi4.c1.biz/ifwi/profile.php"><i class="fas fa-user-circle"></i>Profile</a>
				<a href="https://ifwi4.c1.biz/ifwi/logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
			</div>
		</nav>
		<div class="content">
			<h2>Hosting Manual</h2>
			<div>
				<p>IM Group Hosting Manual</p>
				<table>
					<tr>
						<td>Hi there! I'm guessing you're here because either you were exploring the home page, or you want to have somewhere you can have a website for your code.</td>
					</tr>
					<tr>
						<td>Well, since you're part of the IM Group, you get a free 5 hosting pages on us! Visit the hosting panel <a href="https://ifwi4.c1.biz/hosting/editor.php">here!</a></td>
					</tr>
                    <tr>
                        <td>If you want, you can upgrade to IM Group Premium and get unlimited hosting and a shorter domain! <a href="https://ifwi4.c1.biz/ifwi/misc/premium.php">Get Premium here!</a>
                    </tr>
				</table>
                <table>
                <tr>
                    <td><p><b>Usage Instructions:</b></p></td>
                </tr>
                    <tr>
                        <td> - Your files will be hosted at ifwi4.c1.biz/hosting/USERNAME/FILE. USERNAME is ther username you use to log in. If you want to change your username, contact the admin. </td>
                    </tr>
                    <tr>
                        <td> - The hosting panel only supports HTML, JS, CSS, PHP, and SQL coding languages (that should probably be enough though). All other file types are supported. </td>
					</tr>
                    <tr>
                        <td> - Some features might be a bit buggy, this is expected because I literally coded it myself painfully. </td>
					</tr>	
                    <tr>
                        <td> - File upload is not, and will never be supported. </td>
				    </tr>
                    <tr>
                        <td> - Directory/folder deletion is not supported. If you want to delete one, contact the admin. </td>
					</tr>	
                    <tr>
                        <td> - Anybody that has access to your account has access to your files. TL:DR don't share your password. Unless its me. Because I already know it anyway. Okay, what did you expect?
					</tr>
                    <tr>
                        <td> - Ask questions at the group chat tech channel. </td>						
                    </tr>   
                    <tr>
                        <td><p><b>Hsoting Rules: </b></p></td>
                    </tr>
                    <tr>
 						<td> I, ifwi4, am not repsonsible for any harm/damage done by an individual using my website hosting tools. </td>
					</tr>	
                    <tr>
                        <td> You the user CAN NOT:</td>
                    </tr>
                    <tr>
                        <td> - Put malicious stuff onto any hosting domain. </td>
                    </tr>
                    <tr>
                        <td> - Use your hosting code to modify any of my code. </td>
                    </tr> 
                    <tr>
                        <td> - Use more than 10% of your storage to any archive file (ex. .zip file, .mov file). </td>
                    </tr>
                    <tr>
                        <td> - Not waste my storage through spamming files. </td>
                    </tr>
                    <tr>
                        <td> - Share your hosting with anybody. </td>
                    </tr>
                    <tr>
                        <td> A violation of these rules can result in a loss of hosting rights or a ban from the IM Group depending on severity.</td>
                    </tr>
                </table>
			</div>
		</div>
	</body>
        
        
        
        
        
        
        
        
        
        
        