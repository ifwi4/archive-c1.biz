<?php
session_start();
if (!isset($_SESSION["loggedin"])) {
        header("Location: https://ifwi4.c1.biz/login");
        exit;
} else {
        if ($_SESSION["name"] !== "ifwi4") {
                if ($_SESSION["name"] !== "anon1") {
                        echo "A free proxy for the IM Group is still in progress";
                        echo "If you want premium proxy acesss, consider <a href='https://ifwi4.c1.biz/ifwi/misc/premium.php'>buying a premium plan</a>.";
                }
        }
}