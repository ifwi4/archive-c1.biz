<?php
session_start();
session_destroy();
header('Location: https://ifwi4.c1.biz/login/');
?>