<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
	header('Location: https://ifwi4.c1.biz/login/');
	exit;
}
?>
<html>
<body>

<form action="done.php" method="post">
Chromebook Number: <input type="text" name="number" placeholder="Chromebook Number"><br>
Classroom: <input type="text" name="classroom" placeholder="Chromebook Classroom"><br>
Chrome Version: <input type="text" name="version" placeholder="Chromebook Version"><br>
  <input type="submit">
</form>
You can find your chromebook version by opening the Settings app and searching up "version".

</body>
</html>