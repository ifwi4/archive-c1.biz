<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
	header('Location: https://ifwi4.c1.biz/login/');
	exit;
}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Create a Ticket</title>
		<link href="https://ifwi4.c1.biz/ifwi/style.css" rel="stylesheet" type="text/css">
		<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer">
	</head>
	<body class="loggedin">
		<nav class="navtop">
			<div>
				<h1>Ticket Support</h1>
				<a href="profile.php"><i class="fas fa-user-circle"></i>Profile</a>
				<a href="logout.php"><i class="fas fa-sign-out-alt"></i>Logout</a>
			</div>
		</nav>
		<div class="content">
			<h2>Create a support ticket.</h2>
			<div>
				<td><p>Enter what you want in your ticket below.</p></td>
				<table>
					<tr>
						<td>Message:</td>
                        <form method="post">
						<textarea name="ticket" rows=10 collums=50 placeholder="Put what you want to be sent to the admin here!"></textarea>
					    <button name="submit">Submit your ticket!</button>
                        </form>
                     </tr>
					<tr>
						<td>Question/Feeback:</td>
                            <td>All text that you entered into a ticket form named "Question/Feedback" will be here. Rules: No spamming, no making unnesscary tickets, no being Ben.</td>
					</tr>
					<tr>
						<td>Admin Response</td>
						<td>There might not be a response here depending on if the admin has looked at it yet.</td>
					</tr>
				</table>
			</div>
		</div>
	</body>
</html>
<?php
$ticketNo = rand(1000000, 9999999);
$dir = "ticket/" . $ticketNo;
if (array_key_exists("submit", $_POST)) {
        submitTicket();
}
function submitTicket() {
if (!touch($dir)) {
    $error = error_get_last();
    echo "Error: " . $error['message'];
  } else {
    $ticket 
    file_put_contents($dir, $ticket);
    echo 'The ticket number ' . $ticketNo . ' was sucessfully created. You can view your ticket at ifwi4.c1.biz/ticket/' . $ticketNo;
  }
}
?>













<!-- Made by ifwi4 -->