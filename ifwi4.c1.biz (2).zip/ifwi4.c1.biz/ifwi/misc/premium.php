<?php
session_start();
if (!isset($_SESSION["loggedin"])) {
        header("Location: https://ifwi4.c1.biz/login");
        exit;
}
?>
Hi there! Thank you for considering to purchase/renew an IM Group Premium membership.
<br></br>
Here are some reasons why you should go premium:
<br>
- All money goes directly to IM Group development.
<br>
- Hosting this website is not free, it takes some money and a vast amount of my time developing. If you could help in any way, that would be great.
<br>
- Your money would go to more features on this site thats for you , and everyone!
<br></br>
Some benifits that you get:
<br>
- Premium proxy access
<br>
- A custom rank and description on your profile and on the IM Group Chat
<br>
- Unlimited hosting. Your hosted sites would also go to a shorter domain, ifwi4.c1.biz/file instead of ifwi4.c1.biz/hosting/file.
<br>
- Flexing rights (lol)
<br>
- Ability to file an application for moderator rights or to join the developer team.
<br></br>
If you want to buy premium, it will be $5 USD a month. Keep in mind that it takes roughly 3 times this each month for me to host this website.
<br>
Contact the admin ifwi4 to buy premium.