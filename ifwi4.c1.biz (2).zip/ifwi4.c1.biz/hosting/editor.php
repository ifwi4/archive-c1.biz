<?php
session_start();
if (!isset($_SESSION['loggedin'])) {
       header('Location: https://ifwi4.c1.biz/login');
       exit;
}
?>
<form method="post">
<input name="createdir"></input>
<button name="createdirb">Create directory</button>
</form>
<form method="post">
<input name="createFile"></input>
<button name="create">Create file</button>
Enter directory to create file, Ex. /exampleDirectory/example.file
</form>
<form method="post">
<input name="deleteFile"></input>
<button name="delete">Delete file</button>  
Enter directory to delete file, Ex. /exampleDirectory/example.file
</form>
<form method="post">
<input name="editFile"></input>
<button name="edit">Edit file</button>
</form>
You can view your created files at ifwi4.c1.biz/USERNAME_HERE/file.file
<br></br>
<?php
if (array_key_exists("createdirb", $_POST)) {
        createdir();
}
function createdir() {
        $dir = $_SESSION["name"] . "/" . $_POST["createdir"] . "/";
        if (!file_exists($dir)) {
                mkdir($dir, 0777, true);
                echo "The directory " . $dir . " was successfully created.";
        } else {
                echo "The directory ". $dir . " already exists.";
        }
}
if (array_key_exists("create", $_POST)) { 
        createfile();
}
function createfile() {
        $dir = $_SESSION["name"] . "/" . $_POST["createFile"];
        if (!file_exists($dir)) {
                fopen($dir, "w");
                echo "The file " . $dir . " was sucessfully created.";
        } else {
                echo "The file " . $dir . " already exists.";        
        }
}
if (array_key_exists("delete", $_POST)) { 
        deletefile();
}
function deletefile() {
        $dir = $_SESSION["name"] . "/" . $_POST["deleteFile"];
        if (file_exists($dir)) {
                unlink($dir);
                echo "The file " . $dir . " was deleted successfully.";
        } else {
                echo "The file " . $dir . " does not exist.";
        }
}
if (array_key_exists("edit", $_POST)) {
        editfile();    
}
function editfile() {  
        $dir = $_SESSION['name'] . "/" . $_POST["editFile"];
        if (file_exists($dir)) {
                $content = file_get_contents($dir);
                echo "<form method='post'><input name='dir' value='" . $_POST['editFile'] . "'></input><textarea rows=10 collums=10 placeholder='Enter your file contents here!' name='saveFile'>" . $content . "</textarea><button name='save'>Save file</button></form>";
                echo "The file " . $dir . " is now in editing mode.";        
        } else {
                echo "The file " . $dir . " does not exist.";
        }
}
if (array_key_exists("save", $_POST)) {
        save();  
}
function save() {
        $dir = $_SESSION["name"] . "/" . $_POST["dir"];
        $content = $_POST["saveFile"];
        file_put_contents($dir, $content);
        echo "The file " . $dir ." was saved sucessfully.";
}
?>




























